const {chromium}=require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const fs=require('fs');
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
 const page=await browser.newPage({viewport:{width:1440,height:1300}});const errors=[];page.on('pageerror',e=>errors.push(String(e)));
 await page.goto('http://127.0.0.1:8506');await page.getByRole('heading',{name:'Microsoft Corporation',exact:true}).waitFor({timeout:60000});
 await page.locator('canvas').first().waitFor({state:'visible'});
 async function select(label,value){
  await page.getByTestId('stSelectbox').filter({hasText:label}).getByRole('combobox').click();
  await page.getByRole('option',{name:value,exact:true}).click();await page.waitForTimeout(450);
  if(await page.getByTestId('stException').count())throw new Error(label+' exception');
 }
 const combinations=[];
 for(const history of ['1 semana','4 meses','1 año'])for(const future of ['Ninguna','1 mes','4 meses','1 año','3 años']){
  await select('Histórico de cotización',history);await select('Previsión gráfica',future);combinations.push([history,future]);
 }
 await page.getByTestId('stMain').evaluate(e=>e.scrollTo(0,0));await page.waitForTimeout(700);
 await page.screenshot({path:'/workspace/work/v7_integrada/browser/resumen.png',fullPage:true});
 async function download(prefix){
  await page.getByRole('tab',{name:'Datos y auditoría',exact:true}).click();
  for(const [label,name] of [['Descargar Excel','export.xlsx'],['Descargar resultados JSON','resultados.json'],['Descargar captura reproducible','inputs.json']]){
   const [d]=await Promise.all([page.waitForEvent('download'),page.getByRole('button',{name:label,exact:true}).click()]);await d.saveAs('/workspace/work/v7_integrada/browser/'+prefix+name);
  }
 }
 await download('auto_');
 await page.getByRole('tab',{name:'Resumen',exact:true}).click();
 await page.getByText('Manual',{exact:true}).click();
 await page.getByRole('spinbutton',{name:'PER objetivo Base',exact:true}).fill('20');
 await page.getByRole('textbox',{name:'Justificación del PER',exact:true}).fill('Prueba E2E: sensibilidad funcional, no recomendación');
 await page.getByRole('button',{name:'Aplicar referencia PER',exact:true}).click();await page.waitForTimeout(1000);
 await page.getByRole('tab',{name:'Valoración',exact:true}).click();
 await page.getByRole('button',{name:'Recalcular escenarios',exact:true}).click();await page.waitForTimeout(1000);
 for(const tab of ['Resumen','Histórico','Trimestrales','Comparables','Valoración','Datos y auditoría'])await page.getByRole('tab',{name:tab,exact:true}).click();
 await download('manual_');
 await page.setViewportSize({width:390,height:844});await page.getByRole('tab',{name:'Resumen',exact:true}).click();await page.waitForTimeout(500);
 await page.screenshot({path:'/workspace/work/v7_integrada/browser/movil.png'});
 const width=await page.evaluate(()=>({body:document.body.scrollWidth,viewport:innerWidth}));
 if(width.body>width.viewport+2||errors.length)throw new Error(JSON.stringify({width,errors}));
 fs.writeFileSync('/workspace/work/v7_integrada/browser/verificacion.json',JSON.stringify({combinations,errors,width,tabs:6,exports:6,manual_survives_other_form:true},null,2));
 await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
