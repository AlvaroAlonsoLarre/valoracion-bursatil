import json
from pathlib import Path
import pandas as pd
import grafico_precio_v7
from streamlit.testing.v1 import AppTest
from auditoria_io import clean
import os
grafico_precio_v7.descargar_cierres=lambda *a,**k:pd.DataFrame(columns=['Fecha','Precio'])
p=json.loads(Path('/workspace/work/valoracion-bursatil/docs/v6_simplificada_2026-11-12/inputs/MSFT_after.json').read_text())
p['historical'].pop('Referencia histórica auditada')
p['evidence']['stock_model']['settings']={'per_reason':'Prueba reproducción de estado con PER manual','scenarios':{s:{'pe':20.} for s in ['Pesimista','Base','Optimista']}}
path=Path('/workspace/work/v7_integrada/captura_legacy_manual.json');path.write_text(json.dumps(p));os.environ['VALUACION_DASHBOARD_SNAPSHOT']=str(path)
a=AppTest.from_file('/workspace/work/v7_integrada/local_repro/dashboard_app.py').run(timeout=40)
# La carga por defecto de la V6 descarta también los settings de la captura;
# simular el estado posterior a la importación/manual, sin cambiar sus datos.
a.session_state['settings']=json.dumps(p['evidence']['stock_model']['settings']);a.run(timeout=40)
from flujo_acciones import analysis_from_snapshot
r,_=analysis_from_snapshot(p,json.loads(a.session_state['settings']));print('ANTES',r.summary['primary_available'],r.summary['target_1y'],a.session_state['settings'])
next(b for b in a.button if b.label=='Recalcular escenarios').click();a.run(timeout=40)
r,_=analysis_from_snapshot(p,json.loads(a.session_state['settings']));print('DESPUES',r.summary['primary_available'],r.summary['target_1y'],a.session_state['settings'])
print('EXCEPTIONS',list(a.exception))
Path('/workspace/work/v7_integrada/repro_estado.json').write_text(json.dumps(clean({'antes_disponible':True,'despues_disponible':r.summary['primary_available'],'settings_despues':json.loads(a.session_state['settings'])}),indent=2))
